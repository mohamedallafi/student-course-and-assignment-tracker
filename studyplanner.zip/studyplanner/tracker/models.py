from django.db import models
from django.contrib.auth.models import AbstractUser


class CustomUser(AbstractUser):
    field_of_study = models.CharField(max_length=100, blank=True)
    year_of_study = models.IntegerField(null=True, blank=True)
    profile_picture = models.ImageField(upload_to='profile_pics/', null=True, blank=True)

    def __str__(self):
        return self.username


class Course(models.Model):
    SEMESTER_CHOICES = [
        ('Fall', 'Fall'), ('Spring', 'Spring'), ('Summer', 'Summer'),
    ]
    title = models.CharField(max_length=200)
    course_code = models.CharField(max_length=20)
    instructor = models.CharField(max_length=100, blank=True)
    semester = models.CharField(max_length=10, choices=SEMESTER_CHOICES, blank=True)
    owner = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='courses')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.course_code} – {self.title}"

    @property
    def assignment_count(self):
        return self.assignments.count()

    @property
    def completed_count(self):
        return self.assignments.filter(completed=True).count()


class Assignment(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    due_date = models.DateField()
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='assignments')
    created_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='assignments')
    completed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['due_date']

    def __str__(self):
        return f"{self.title} ({self.course.course_code})"


class StudyTask(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    planned_date = models.DateField()
    duration = models.DecimalField(max_digits=4, decimal_places=1, help_text="Duration in hours")
    related_assignment = models.ForeignKey(Assignment, on_delete=models.SET_NULL, null=True, blank=True, related_name='study_tasks')
    completed = models.BooleanField(default=False)
    owner = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='study_tasks')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['planned_date']

    def __str__(self):
        return self.title
