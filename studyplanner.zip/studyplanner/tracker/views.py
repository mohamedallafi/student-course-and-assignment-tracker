from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from datetime import date, timedelta
from .models import Course, Assignment, StudyTask
from .forms import RegisterForm, LoginForm, ProfileForm, CourseForm, AssignmentForm, StudyTaskForm


def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    form = RegisterForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, f'Welcome, {user.username}! Your account has been created.')
        return redirect('dashboard')
    return render(request, 'auth/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    form = LoginForm(request, data=request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.get_user()
        login(request, user)
        return redirect('dashboard')
    return render(request, 'auth/login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('login')


@login_required
def dashboard(request):
    today = date.today()
    week_end = today + timedelta(days=7)
    upcoming_assignments = Assignment.objects.filter(
        created_by=request.user, completed=False, due_date__gte=today, due_date__lte=week_end
    ).select_related('course')
    overdue_assignments = Assignment.objects.filter(
        created_by=request.user, completed=False, due_date__lt=today
    ).select_related('course')
    today_tasks = StudyTask.objects.filter(owner=request.user, planned_date=today)
    week_tasks = StudyTask.objects.filter(owner=request.user, planned_date__gte=today, planned_date__lte=week_end)
    total_courses = Course.objects.filter(owner=request.user).count()
    total_assignments = Assignment.objects.filter(created_by=request.user).count()
    completed_assignments = Assignment.objects.filter(created_by=request.user, completed=True).count()
    total_tasks = StudyTask.objects.filter(owner=request.user).count()
    completed_tasks = StudyTask.objects.filter(owner=request.user, completed=True).count()
    progress = round((completed_assignments / total_assignments * 100) if total_assignments else 0)
    return render(request, 'tracker/dashboard.html', {
        'upcoming_assignments': upcoming_assignments,
        'overdue_assignments': overdue_assignments,
        'today_tasks': today_tasks,
        'week_tasks': week_tasks,
        'total_courses': total_courses,
        'total_assignments': total_assignments,
        'completed_assignments': completed_assignments,
        'total_tasks': total_tasks,
        'completed_tasks': completed_tasks,
        'progress': progress,
        'today': today,
    })


@login_required
def profile_view(request):
    form = ProfileForm(request.POST or None, request.FILES or None, instance=request.user)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Profile updated successfully.')
        return redirect('profile')
    return render(request, 'tracker/profile.html', {'form': form})


# --- COURSES ---
@login_required
def course_list(request):
    courses = Course.objects.filter(owner=request.user).prefetch_related('assignments')
    return render(request, 'tracker/courses/list.html', {'courses': courses})


@login_required
def course_create(request):
    form = CourseForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        course = form.save(commit=False)
        course.owner = request.user
        course.save()
        messages.success(request, f'Course "{course}" added.')
        return redirect('course_list')
    return render(request, 'tracker/courses/form.html', {'form': form, 'title': 'Add Course'})


@login_required
def course_edit(request, pk):
    course = get_object_or_404(Course, pk=pk, owner=request.user)
    form = CourseForm(request.POST or None, instance=course)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Course updated.')
        return redirect('course_list')
    return render(request, 'tracker/courses/form.html', {'form': form, 'title': 'Edit Course'})


@login_required
def course_delete(request, pk):
    course = get_object_or_404(Course, pk=pk, owner=request.user)
    if request.method == 'POST':
        course.delete()
        messages.success(request, 'Course deleted.')
        return redirect('course_list')
    return render(request, 'tracker/confirm_delete.html', {'object': course, 'type': 'Course'})


# --- ASSIGNMENTS ---
@login_required
def assignment_list(request):
    assignments = Assignment.objects.filter(created_by=request.user).select_related('course')
    course_filter = request.GET.get('course')
    status_filter = request.GET.get('status')
    if course_filter:
        assignments = assignments.filter(course_id=course_filter)
    if status_filter == 'completed':
        assignments = assignments.filter(completed=True)
    elif status_filter == 'pending':
        assignments = assignments.filter(completed=False)
    courses = Course.objects.filter(owner=request.user)
    return render(request, 'tracker/assignments/list.html', {
        'assignments': assignments, 'courses': courses,
        'course_filter': course_filter, 'status_filter': status_filter
    })


@login_required
def assignment_create(request):
    form = AssignmentForm(user=request.user, data=request.POST or None)
    if request.method == 'POST' and form.is_valid():
        assignment = form.save(commit=False)
        assignment.created_by = request.user
        assignment.save()
        messages.success(request, f'Assignment "{assignment.title}" added.')
        return redirect('assignment_list')
    return render(request, 'tracker/assignments/form.html', {'form': form, 'title': 'Add Assignment'})


@login_required
def assignment_edit(request, pk):
    assignment = get_object_or_404(Assignment, pk=pk, created_by=request.user)
    form = AssignmentForm(user=request.user, data=request.POST or None, instance=assignment)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Assignment updated.')
        return redirect('assignment_list')
    return render(request, 'tracker/assignments/form.html', {'form': form, 'title': 'Edit Assignment'})


@login_required
def assignment_delete(request, pk):
    assignment = get_object_or_404(Assignment, pk=pk, created_by=request.user)
    if request.method == 'POST':
        assignment.delete()
        messages.success(request, 'Assignment deleted.')
        return redirect('assignment_list')
    return render(request, 'tracker/confirm_delete.html', {'object': assignment, 'type': 'Assignment'})


@login_required
def assignment_toggle(request, pk):
    assignment = get_object_or_404(Assignment, pk=pk, created_by=request.user)
    assignment.completed = not assignment.completed
    assignment.save()
    return redirect(request.META.get('HTTP_REFERER', 'assignment_list'))


# --- STUDY TASKS ---
@login_required
def task_list(request):
    tasks = StudyTask.objects.filter(owner=request.user).select_related('related_assignment')
    date_filter = request.GET.get('date')
    if date_filter:
        tasks = tasks.filter(planned_date=date_filter)
    return render(request, 'tracker/tasks/list.html', {'tasks': tasks, 'date_filter': date_filter})


@login_required
def task_create(request):
    form = StudyTaskForm(user=request.user, data=request.POST or None)
    if request.method == 'POST' and form.is_valid():
        task = form.save(commit=False)
        task.owner = request.user
        task.save()
        messages.success(request, f'Task "{task.title}" added.')
        return redirect('task_list')
    return render(request, 'tracker/tasks/form.html', {'form': form, 'title': 'Add Study Task'})


@login_required
def task_edit(request, pk):
    task = get_object_or_404(StudyTask, pk=pk, owner=request.user)
    form = StudyTaskForm(user=request.user, data=request.POST or None, instance=task)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Task updated.')
        return redirect('task_list')
    return render(request, 'tracker/tasks/form.html', {'form': form, 'title': 'Edit Study Task'})


@login_required
def task_delete(request, pk):
    task = get_object_or_404(StudyTask, pk=pk, owner=request.user)
    if request.method == 'POST':
        task.delete()
        messages.success(request, 'Task deleted.')
        return redirect('task_list')
    return render(request, 'tracker/confirm_delete.html', {'object': task, 'type': 'Study Task'})


@login_required
def task_toggle(request, pk):
    task = get_object_or_404(StudyTask, pk=pk, owner=request.user)
    task.completed = not task.completed
    task.save()
    return redirect(request.META.get('HTTP_REFERER', 'task_list'))


# --- ADMIN ---
@login_required
def admin_users(request):
    if not request.user.is_staff:
        return redirect('dashboard')
    from .models import CustomUser
    users = CustomUser.objects.all().order_by('-date_joined')
    return render(request, 'tracker/admin/users.html', {'users': users})
