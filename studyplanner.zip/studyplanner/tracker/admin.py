from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, Course, Assignment, StudyTask

@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        ('Academic Info', {'fields': ('field_of_study', 'year_of_study', 'profile_picture')}),
    )
    list_display = ['username', 'email', 'field_of_study', 'year_of_study', 'is_staff']

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ['course_code', 'title', 'instructor', 'semester', 'owner']
    list_filter = ['semester']

@admin.register(Assignment)
class AssignmentAdmin(admin.ModelAdmin):
    list_display = ['title', 'course', 'due_date', 'completed', 'created_by']
    list_filter = ['completed', 'due_date']

@admin.register(StudyTask)
class StudyTaskAdmin(admin.ModelAdmin):
    list_display = ['title', 'planned_date', 'duration', 'completed', 'owner']
    list_filter = ['completed', 'planned_date']
