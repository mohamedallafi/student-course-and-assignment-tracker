from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import CustomUser, Course, Assignment, StudyTask


class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)
    field_of_study = forms.CharField(max_length=100, required=False)
    year_of_study = forms.IntegerField(required=False, min_value=1, max_value=8)

    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'field_of_study', 'year_of_study', 'password1', 'password2']


class LoginForm(AuthenticationForm):
    pass


class ProfileForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ['first_name', 'last_name', 'email', 'field_of_study', 'year_of_study', 'profile_picture']
        widgets = {'profile_picture': forms.FileInput()}


class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['title', 'course_code', 'instructor', 'semester']
        widgets = {
            'title': forms.TextInput(attrs={'placeholder': 'e.g. Python for Web Application'}),
            'course_code': forms.TextInput(attrs={'placeholder': 'e.g. ITEC320'}),
            'instructor': forms.TextInput(attrs={'placeholder': 'Instructor name'}),
        }


class AssignmentForm(forms.ModelForm):
    class Meta:
        model = Assignment
        fields = ['title', 'description', 'due_date', 'course', 'completed']
        widgets = {
            'due_date': forms.DateInput(attrs={'type': 'date'}),
            'description': forms.Textarea(attrs={'rows': 3}),
        }

    def __init__(self, user=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if user:
            self.fields['course'].queryset = Course.objects.filter(owner=user)


class StudyTaskForm(forms.ModelForm):
    class Meta:
        model = StudyTask
        fields = ['title', 'description', 'planned_date', 'duration', 'related_assignment', 'completed']
        widgets = {
            'planned_date': forms.DateInput(attrs={'type': 'date'}),
            'description': forms.Textarea(attrs={'rows': 3}),
            'duration': forms.NumberInput(attrs={'step': '0.5', 'placeholder': 'Hours'}),
        }

    def __init__(self, user=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if user:
            self.fields['related_assignment'].queryset = Assignment.objects.filter(created_by=user)
        self.fields['related_assignment'].required = False
