# StudyTrack — Study Planner & Assignment Tracker

A Django web application for university students to manage courses, assignments, and study tasks.

## Setup

```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Visit http://127.0.0.1:8000

## Default Admin
- Username: admin
- Password: admin123

## Features
- Custom user authentication (register/login/profile)
- Course management
- Assignment tracking with due dates & completion
- Study task planning with duration
- Dashboard with progress stats & overdue alerts
- Admin panel to view all users
